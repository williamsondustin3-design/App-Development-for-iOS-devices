//
//  FoodImageView.swift
//  DesignPattern
//
//  Created by Dustin Williamson on 11/12/25.
//

import UIKit
class FoodImageView: UIImageView {
    var foodName: String = ""
    var protein: Double = 0
    var fat: Double = 0
    var carbs: Double = 0
    var calories: Double = 0
}
