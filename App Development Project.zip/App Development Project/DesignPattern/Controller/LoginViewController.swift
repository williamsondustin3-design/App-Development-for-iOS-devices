//
//  LoginViewController.swift
//  DesignPattern
//
//
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var loginBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        emailField.addTarget(self, action: #selector(validateFields), for: .editingChanged)
        
        passwordField.addTarget(self, action: #selector(validateFields), for: .editingChanged)
    }
    
    @objc private func validateFields(){
        loginBtn.isEnabled = emailField.text != "" && passwordField.text != ""
    }
    
    @IBAction func loginBtnClicked(_ sender: UIButton) {
        
        NetworkServices.shared.login(email: emailField.text!, password: passwordField.text!) {success in
            if success{
                self.gotoHomePage()
            } else {
                
                print("Invalid Credentials")
            }
        }
    }
    
    func gotoHomePage(){
        let controller = storyboard?.instantiateViewController(withIdentifier: "MainPageViewController")as! MainPageViewController
        
        present(controller, animated: true, completion: nil)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}
