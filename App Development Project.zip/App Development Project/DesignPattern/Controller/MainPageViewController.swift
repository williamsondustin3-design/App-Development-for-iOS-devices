//
//  MainPageViewController.swift
//  DesignPattern
//
//  Created by  on 12/3/25.
//

import UIKit

class MainPageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .systemOrange
        setupButtons()
    }

    private func setupButtons() {

     
        let menuButton = UIButton(type: .system)
        menuButton.setTitle("Menu", for: .normal)
        menuButton.titleLabel?.font = .systemFont(ofSize: 22, weight: .bold)
        menuButton.frame = CGRect(x: 20, y: 60, width: 120, height: 40)
        menuButton.addTarget(self, action: #selector(openMenu), for: .touchUpInside)
        view.addSubview(menuButton)


        let foodButton = UIButton(type: .system)
        foodButton.setTitle("Go to Food Tracker", for: .normal)
        foodButton.titleLabel?.font = .systemFont(ofSize: 20, weight: .semibold)
        foodButton.frame = CGRect(x: 20, y: 120, width: 250, height: 50)
        foodButton.addTarget(self, action: #selector(openHomePage), for: .touchUpInside)
        view.addSubview(foodButton)
    }

    @objc private func openMenu() {
        if let menuVC = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as? MenuViewController {
            menuVC.modalPresentationStyle = .fullScreen   // or .overCurrentContext
            present(menuVC, animated: true)
        }
    }


    @objc private func openHomePage() {
        if let controller = storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController {
            present(controller, animated: true)
        } else {
            print("Could not load HomeViewController — check storyboard ID")
        }
    }
}
