import UIKit

class MenuViewController: UIViewController {

    let stack = UIStackView()

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .systemOrange
        setupMenuUI()
    }

    private func setupMenuUI() {

        // StackView for layout
        stack.axis = .vertical
        stack.spacing = 20
        stack.alignment = .leading
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 30),
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30)
        ])

        // Close Button
        let closeBtn = makeButton(title: "Close Menu", action: #selector(closeMenu))
        stack.addArrangedSubview(closeBtn)

        // Food Tracker
        let foodBtn = makeButton(title: "Food Tracker", action: #selector(openFoodTracker))
        stack.addArrangedSubview(foodBtn)

        // Dark Mode Toggle
        let darkModeSwitch = UISwitch()
        darkModeSwitch.addTarget(self, action: #selector(toggleDarkMode(_:)), for: .valueChanged)
        stack.addArrangedSubview(makeSwitchRow(title: "Dark Mode", toggle: darkModeSwitch))

        // Face ID Toggle
        let faceIdSwitch = UISwitch()
        faceIdSwitch.addTarget(self, action: #selector(toggleFaceID(_:)), for: .valueChanged)
        stack.addArrangedSubview(makeSwitchRow(title: "Enable Face ID", toggle: faceIdSwitch))

        // Logout
        let logoutBtn = makeButton(title: "Log Out", action: #selector(logout))
        logoutBtn.setTitleColor(.systemRed, for: .normal)
        stack.addArrangedSubview(logoutBtn)
    }

    // MARK: — Button Makers

    private func makeButton(title: String, action: Selector) -> UIButton {
        let btn = UIButton(type: .system)
        btn.setTitle(title, for: .normal)
        btn.titleLabel?.font = .systemFont(ofSize: 23, weight: .semibold)
        btn.contentHorizontalAlignment = .left
        btn.addTarget(self, action: action, for: .touchUpInside)
        return btn
    }

    private func makeSwitchRow(title: String, toggle: UISwitch) -> UIView {
        let container = UIStackView()
        container.axis = .horizontal
        container.spacing = 10
        container.alignment = .center

        let label = UILabel()
        label.text = title
        label.font = .systemFont(ofSize: 23)

        container.addArrangedSubview(label)
        container.addArrangedSubview(toggle)
        return container
    }

    // MARK: — Button Actions

    @objc private func closeMenu() {
        dismiss(animated: true)
    }

    @objc private func openFoodTracker() {
        if let controller = storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController {
            controller.modalPresentationStyle = .fullScreen
            present(controller, animated: true)
        }
    }

    @objc private func logout() {
        if let loginVC = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {
            loginVC.modalPresentationStyle = .fullScreen
            present(loginVC, animated: true)
        }
    }

    // MARK: — Toggles

    @objc private func toggleDarkMode(_ sender: UISwitch) {
        overrideUserInterfaceStyle = sender.isOn ? .dark : .light
    }

    @objc private func toggleFaceID(_ sender: UISwitch) {
        print("Face ID Enabled? \(sender.isOn)")
        // You will later add LocalAuthentication here
    }
}
