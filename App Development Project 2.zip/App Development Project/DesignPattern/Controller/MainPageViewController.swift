//
//  MainPageViewController.swift
//  DesignPattern
//
//  Created by  on 12/3/25.
//

import UIKit

class MainPageViewController: UIViewController {

    
    @IBAction func openMenu(_ sender: Any) {
        if let menuVC = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as? MenuViewController {
                menuVC.modalPresentationStyle = .pageSheet
                present(menuVC, animated: true)
            }
    }
    
    @IBAction func openTracker(_ sender: Any) {
        if let controller = storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController {
            controller.modalPresentationStyle = .fullScreen
            present(controller, animated: true)
            }
    }
    
    @IBAction func editProfile(_ sender: Any) {
        if let editVC = storyboard?.instantiateViewController(withIdentifier: "EditProfileViewController") as? EditProfileViewController {
            editVC.modalPresentationStyle = .fullScreen
            present(editVC, animated: true)
            }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .systemOrange

    }
}
