//
//  EditProfileController.swift
//  DesignPattern
//
//  Created by  on 12/5/25.
//

import UIKit

class EditProfileViewController: UIViewController {

    @IBOutlet weak var firstNameField: UITextField!
    @IBOutlet weak var lastNameField: UITextField!
    @IBOutlet weak var weightField: UITextField!
    @IBOutlet weak var calorieGoalField: UITextField!
    @IBOutlet weak var saveButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        loadSavedProfile()
    }

    @IBAction func saveButtonTapped(_ sender: Any) {
        saveProfile()
    }
    @IBAction func openHome(_ sender: Any) {
        if let homeVC = storyboard?.instantiateViewController(withIdentifier: "MainPageViewController") as? MainPageViewController {
            homeVC.modalPresentationStyle = .fullScreen
            present(homeVC, animated: true)
            }
    }

    func saveProfile() {
        let defaults = UserDefaults.standard

        defaults.set(firstNameField.text ?? "", forKey: "firstName")
        defaults.set(lastNameField.text ?? "", forKey: "lastName")
        defaults.set(weightField.text ?? "", forKey: "weight")
        defaults.set(calorieGoalField.text ?? "", forKey: "calorieGoal")

        defaults.synchronize()

        let alert = UIAlertController(title: "Saved",
                                      message: "Your profile has been saved.",
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    func loadSavedProfile() {
        let defaults = UserDefaults.standard

        firstNameField.text = defaults.string(forKey: "firstName") ?? ""
        lastNameField.text = defaults.string(forKey: "lastName") ?? ""
        weightField.text = defaults.string(forKey: "weight") ?? ""
        calorieGoalField.text = defaults.string(forKey: "calorieGoal") ?? ""
    }
}
