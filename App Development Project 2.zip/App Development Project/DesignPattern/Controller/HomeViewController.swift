//
//  HomeViewController.swift
//  DesignPattern
//
//  
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var steakImage: FoodImageView!
    @IBOutlet weak var salmonImage: FoodImageView!
    @IBOutlet weak var proteinShake: FoodImageView!
    @IBOutlet weak var chickenImage: FoodImageView!
    @IBOutlet weak var cheeseImage: FoodImageView!
    @IBOutlet weak var breadImage: FoodImageView!
    @IBOutlet weak var pastaImage: FoodImageView!
    @IBOutlet weak var oatmealImage: FoodImageView!
    @IBOutlet weak var mixedNuts: FoodImageView!
    @IBOutlet weak var whiteRice: FoodImageView!
    @IBOutlet weak var bananaImage: FoodImageView!
    @IBOutlet weak var mixedVegetables: FoodImageView!
    @IBOutlet weak var peanutButter: FoodImageView!
    
    
    @IBOutlet weak var totalCaloriesLabel: UILabel!
    @IBOutlet weak var totalProteinLabel: UILabel!
    @IBOutlet weak var totalFatLabel: UILabel!
    @IBOutlet weak var totalCarbsLabel: UILabel!
    
    @IBAction func logOut(_ sender: Any) {
        if let logVC = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {
                logVC.modalPresentationStyle = .pageSheet
                present(logVC, animated: true)
            }
    }
    
    @IBAction func openMenu(_ sender: Any) {
        if let menuVC = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as? MenuViewController {
                menuVC.modalPresentationStyle = .pageSheet
                present(menuVC, animated: true)
            }
    }
    
    var totalProtein: Double = 0
    var totalFat: Double = 0
    var totalCarbs: Double = 0
    var totalCalories: Double = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let tap = UITapGestureRecognizer(target: self, action: #selector(foodTapped(_:)))
        view.addGestureRecognizer(tap)

        chickenImage.foodName = "Chicken Breast"
        chickenImage.protein = 0.31
        chickenImage.fat = 0.04
        chickenImage.carbs = 0
        chickenImage.calories = 1.65

        salmonImage.foodName = "Salmon"
        salmonImage.protein = 0.22
        salmonImage.fat = 0.13
        salmonImage.carbs = 0
        salmonImage.calories = 2.08

        whiteRice.foodName = "White Rice"
        whiteRice.protein = 0.026
        whiteRice.fat = 0.003
        whiteRice.carbs = 0.28
        whiteRice.calories = 1.30

        peanutButter.foodName = "Peanut Butter"
        peanutButter.protein = 0.25
        peanutButter.fat = 0.50
        peanutButter.carbs = 0.21
        peanutButter.calories = 5.9
            
        steakImage.foodName = "Steak"
        steakImage.protein = 0.26
        steakImage.fat = 0.1
        steakImage.carbs = 0
        steakImage.calories = 3
        
        proteinShake.foodName = "Protein Shake"
        proteinShake.protein = 0.75
        proteinShake.fat = 0.05
        proteinShake.carbs = 0.15
        proteinShake.calories = 3.8
        
        cheeseImage.foodName = "Cheese"
        cheeseImage.protein = 0.25
        cheeseImage.fat = 0.33
        cheeseImage.carbs = 0.01
        cheeseImage.calories = 4.02
        
        breadImage.foodName = "Bread"
        breadImage.protein = 0.09
        breadImage.fat = 0.02
        breadImage.carbs = 0.50
        breadImage.calories = 2.6
        
        pastaImage.foodName = "Pasta"
        pastaImage.protein = 0.055
        pastaImage.fat = 0.007
        pastaImage.carbs = 0.31
        pastaImage.calories = 1.57
        
        oatmealImage.foodName = "Oatmeal"
        oatmealImage.protein = 0.13
        oatmealImage.fat = 0.07
        oatmealImage.carbs = 0.67
        oatmealImage.calories = 3.79
        
        mixedNuts.foodName = "Mixed Nuts"
        mixedNuts.protein = 0.17
        mixedNuts.fat = 0.52
        mixedNuts.carbs = 0.20
        mixedNuts.calories = 5.9
        
        bananaImage.foodName = "Banana"
        bananaImage.protein = 0.011
        bananaImage.fat = 0.003
        bananaImage.carbs = 0.23
        bananaImage.calories = 0.89
        
        mixedVegetables.foodName = "Mixed Vegetables"
        mixedVegetables.protein = 0.03
        mixedVegetables.fat = 0.003
        mixedVegetables.carbs = 0.14
        mixedVegetables.calories = 0.70
            
        enableTap(chickenImage)
        enableTap(salmonImage)
        enableTap(whiteRice)
        enableTap(peanutButter)
        enableTap(steakImage)
        enableTap(proteinShake)
        enableTap(cheeseImage)
        enableTap(breadImage)
        enableTap(pastaImage)
        enableTap(oatmealImage)
        enableTap(mixedNuts)
        enableTap(bananaImage)
        enableTap(mixedVegetables)
        }

    func enableTap(_ imageView: FoodImageView) {
        imageView.isUserInteractionEnabled = true
        let tap = UITapGestureRecognizer(target: self, action: #selector(foodTapped(_:)))
        imageView.addGestureRecognizer(tap)
        }
    func updateTotalsUI() {
        totalProteinLabel.text = String(format: "%.1f g", totalProtein)
        totalFatLabel.text = String(format: "%.1f g", totalFat)
        totalCarbsLabel.text = String(format: "%.1f g", totalCarbs)
        totalCaloriesLabel.text = String(format: "%.0f kcal", totalCalories)
    }

    @objc func foodTapped(_ sender: UITapGestureRecognizer) {
            let location = sender.location(in: view)

            if let tappedView = view.hitTest(location, with: nil) as? FoodImageView {
                let alert = UIAlertController(
                    title: "Enter weight (g)",
                    message: "How many grams of \(tappedView.foodName)?",
                    preferredStyle: .alert
                )

                alert.addTextField { textField in
                    textField.placeholder = "Enter grams"
                    textField.keyboardType = .decimalPad
                }

                alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                    if let gramsText = alert.textFields?.first?.text,
                       let grams = Double(gramsText) {

                        let protein = tappedView.protein * grams
                        let fat = tappedView.fat * grams
                        let carbs = tappedView.carbs * grams
                        let calories = tappedView.calories * grams

                        // Add to totals
                        self.totalProtein += protein
                        self.totalFat += fat
                        self.totalCarbs += carbs
                        self.totalCalories += calories

                        self.updateTotalsUI()
                }
            })
            
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            present(alert, animated: true)
        }
    }

}
