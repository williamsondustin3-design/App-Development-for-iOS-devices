//
//  MenuViewController.swift
//  DesignPattern
//

import UIKit

class MenuViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemOrange
    }

    @IBOutlet weak var faceID: UISwitch!
    @IBOutlet weak var darkMode: UISwitch!
    @IBAction func closeMenuTapped(_ sender: Any) {
        dismiss(animated: true)
    }
    @IBAction func openHome(_ sender: Any) {
        if let homeVC = storyboard?.instantiateViewController(withIdentifier: "MainPageViewController") as? MainPageViewController {
            homeVC.modalPresentationStyle = .fullScreen
            present(homeVC, animated: true)
            }
    }

    @IBAction func darkModeSwitchChanged(_ sender: UISwitch) {
        let enabled = sender.isOn
        UserDefaults.standard.set(enabled, forKey: "darkModeEnabled")

        if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let delegate = scene.delegate as? SceneDelegate {
            delegate.applyAppAppearance()}
    }

    @IBAction func faceIDSwitchChanged(_ sender: UISwitch) {
            UserDefaults.standard.set(sender.isOn, forKey: "faceIDEnabled")
            print("Face ID Enabled? \(sender.isOn)")
    }

    @IBAction func logoutTapped(_ sender: Any) {
        if let logVC = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {
                logVC.modalPresentationStyle = .pageSheet
                present(logVC, animated: true)
            }
    }
    
    override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)

            let savedDark = UserDefaults.standard.bool(forKey: "darkModeEnabled")
            darkMode.isOn = savedDark

            overrideUserInterfaceStyle = savedDark ? .dark : .light

            faceID.isOn = UserDefaults.standard.bool(forKey: "faceIDEnabled")
        }
}
