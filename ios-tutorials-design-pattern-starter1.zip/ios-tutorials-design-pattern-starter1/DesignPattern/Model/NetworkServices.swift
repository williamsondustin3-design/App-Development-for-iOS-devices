//
//  NetworkServices.swift
//  DesignPattern
//
//  Created by  on 10/16/25.
//

import Foundation

class NetworkServices {
    static let shared = NetworkServices()
    private init(){
        
    }
    
    private var user: User?
    
    func login(email: String, password: String, completion: @escaping(Bool) -> Void){
        DispatchQueue.global().async{
            sleep(2)
            DispatchQueue.main.async {
                if email == "test@test.com" && password == "password"{
                    completion(true)
                    
                    self.user = User(firstName: "Dustin", lastName: "Williamson", Email:"abc@gmail.com", age: 22, location:Location(lat: 2.134, lng: -6.123))
                    completion(true)
                } else {
                    self.user = nil
                    completion(false)
                }
            }
        }
    }
    
    func getLoggedInUser() -> User? {
        return user
    }
}
