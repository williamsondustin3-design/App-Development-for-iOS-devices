//
//  User.swift
//  DesignPattern
//
//  Created by  on 10/16/25.
//

import Foundation
struct User{
    let firstName, lastName, Email: String
    let age: Int
    let location: Location
}

struct Location{
    let lat: Double
    let lng: Double
}


