//
//  HomeViewController.swift
//  DesignPattern
//
//  
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var welcomeLbl: UILabel!
    
    var user: User?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.user = NetworkServices.shared.getLoggedInUser()
        welcomeUser()

    }
    func welcomeUser(){
        welcomeLbl.text = "Welcome, \(user?.firstName ?? "User") \(user?.lastName ?? "User")"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
