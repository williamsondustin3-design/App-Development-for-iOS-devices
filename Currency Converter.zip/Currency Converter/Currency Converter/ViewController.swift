//
//  ViewController.swift
//  Currency Converter
//
//  Created by  on 11/10/25.
//

import UIKit




class ViewController: UIViewController {
    
    
    @IBOutlet weak var cadLabel: UILabel!
    
    @IBOutlet weak var chfLabel: UILabel!
    
    @IBOutlet weak var gbpLabel: UILabel!
    
    @IBOutlet weak var jpyLabel: UILabel!
    
    @IBOutlet weak var usdLabel: UILabel!
    
    @IBOutlet weak var tryLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }
    
    @IBAction func getRatesClicked(_ sender: Any) {
        
        let url = URL(string: "http://data.fixer.io/api/latest?access_key=da7efacd7ef4d4aa95ded28f5cd991f6")
        let session = URLSession.shared
        
        let task = session.dataTask(with: url!) { (data, response, error) in if error != nil {
            let alert = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: UIAlertController.Style.alert)
            let okButton = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
            alert.addAction(okButton)
            self.present(alert, animated: true, completion: nil)
            } else {
                if data != nil{
                    do {
                        let jsonResponse = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! Dictionary<String, Any>
                        
                        DispatchQueue.main.async {
                            if let rates = jsonResponse["rates"] as? [String: Any]{
                                //print(rates)
                                if let cad = rates["CAD"] as? Double{
                                    //print(cad)
                                    self.cadLabel.text = "CAD: \(cad)"
                                }
                                if let chf = rates["CHF"] as? Double{
                                    //print(cad)
                                    self.cadLabel.text = "CHF: \(chf)"
                                }
                                if let gbp = rates["GBP"] as? Double{
                                    //print(cad)
                                    self.cadLabel.text = "GBP: \(gbp)"
                                }
                                if let jpy = rates["JPY"] as? Double{
                                    //print(cad)
                                    self.cadLabel.text = "JPY: \(jpy)"
                                }
                                if let usd = rates["USD"] as? Double{
                                    //print(cad)
                                    self.cadLabel.text = "USD: \(usd)"
                                }
                                if let turkish = rates["Try"] as? Double{
                                    //print(cad)
                                    self.cadLabel.text = "TRY: \(turkish)"
                                }
                            }
                        }
                        
                    } catch {
                        print("error")
                        }
                    }
                
                }
            }
        task.resume()
    }
}
